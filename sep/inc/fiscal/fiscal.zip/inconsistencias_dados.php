<?php
	$dataInicialMysql = DataMysql($dataInicial);
	$dataFinalMysql   = DataMysql($dataFinal);
	//Verifica o numero de NF emitidas
	/*$sql_nf_emitidas = mysql_query("
		SELECT 
			COUNT(codigo) AS quantidade 
		FROM 
			notas
		WHERE
			DATE(datahoraemissao) >= '$dataInicialMysql' AND DATE(datahoraemissao) <= '$dataFinalMysql'
	");*/
	$sql_nf_emitidas = mysql_query("
		SELECT * FROM notas AS n
		INNER JOIN cadastro AS c ON c.codigo=n.codemissor
		WHERE datahoraemissao BETWEEN '$dataInicialMysql' AND '$dataFinalMysql'
		GROUP BY n.codemissor, n.numero");
	$nf_emitidas = mysql_num_rows($sql_nf_emitidas);
	
	$sql_nf_emitidas_tomador = mysql_query("
		SELECT * FROM notas_tomadas AS nt
		INNER JOIN notas AS n ON n.codemissor=nt.codtomador AND n.numero=nt.numero
		WHERE datahoraemissao BETWEEN '$dataInicialMysql' AND '$dataFinalMysql' AND nt.estado<>'C'");
	$nf_emitidas_tomador = mysql_num_rows($sql_nf_emitidas_tomador);
	
	$sql_nf_divirgentes = mysql_query("
		SELECT * FROM notas
		WHERE datahoraemissao BETWEEN '$dataInicialMysql' AND '$dataFinalMysql'
		AND codemissor NOT IN (SELECT codigo FROM cadastro)");
	$nf_divirgentes = mysql_num_rows($sql_nf_divirgentes);
	
	$sql_nf_emitidas_tomador_divirgentes = mysql_query("
		SELECT * FROM notas_tomadas AS nt
		WHERE data BETWEEN '2010-10-01' AND '2010-10-30' AND nt.estado<>'C'
		AND codtomador in (SELECT codemissor FROM notas) AND numero NOT in (SELECT numero FROM notas)");
	$nf_emitidas_tomador_divirgentes = mysql_num_rows($sql_nf_emitidas_tomador_divirgentes);
	
	//pega todos os prestadores
	$cntPrest = $contN = $cntNt = 0;
	$sql_prestadores= mysql_query("SELECT * FROM notas GROUP BY codemissor");
	while($prestador=mysql_fetch_array($sql_prestadores)){
		$cntPrest++;
		//echo $prestador['codemissor'];
		//para cada prestador pega as notas
		$sql_nota= mysql_query("SELECT * FROM notas WHERE codemissor='{$prestador['codemissor']}'");
			while($nota=mysql_fetch_array($sql_prestadores)){
				$contN++;
				//echo $nota['numero'];
				//para cada nota verifica se tem par
				$sql_notasDeclaradas= mysql_query("SELECT * FROM notas_tomadas WHERE  codtomador={$prestador['codemissor']} and numero={$nota['numero']} and estado<>'C'");
				while($declaradas=mysql_fetch_array($sql_notasDeclaradas)){
					$cntNt++;
				}
			}
	}
	//echo "cntPrest-$cntPrest | contN-$contN | contN-$contN";
	
?>